#!/usr/bin/env node
// ============================================================
//  🦞 ClawFather — CLI Setup Wizard + Telegram Bot
// ============================================================
//  Chạy:  node clawfather.js
//
//  Wizard trên terminal hỏi bạn:
//   1. Telegram Bot Token
//   2. OpenAI-compatible endpoint + key + model
//   3. Mô tả bot muốn tạo → AI tự build prompt & pipeline
//   4. Review → Chạy bot
// ============================================================

const readline = require("readline");
const fs = require("fs");
const path = require("path");
const OpenAI = require("openai");

// ── ANSI Colors ─────────────────────────────────────────────
const c = {
  reset: "\x1b[0m", bold: "\x1b[1m", dim: "\x1b[2m",
  red: "\x1b[31m", green: "\x1b[32m", yellow: "\x1b[33m",
  blue: "\x1b[34m", magenta: "\x1b[35m", cyan: "\x1b[36m",
};

const log = {
  info: (m) => console.log(`${c.cyan}ℹ${c.reset} ${m}`),
  ok: (m) => console.log(`${c.green}✅${c.reset} ${m}`),
  err: (m) => console.log(`${c.red}❌${c.reset} ${m}`),
  warn: (m) => console.log(`${c.yellow}⚠${c.reset} ${m}`),
  step: (n, t, m) => console.log(`\n${c.bold}${c.blue}[${n}/${t}]${c.reset} ${c.bold}${m}${c.reset}`),
  dim: (m) => console.log(`${c.dim}  ${m}${c.reset}`),
  bot: (m) => console.log(`${c.green}🦞${c.reset} ${m}`),
};

function banner() {
  console.log(`
${c.bold}${c.magenta}   ██████╗██╗      █████╗ ██╗    ██╗
  ██╔════╝██║     ██╔══██╗██║    ██║
  ██║     ██║     ███████║██║ █╗ ██║
  ██║     ██║     ██╔══██║██║███╗██║
  ╚██████╗███████╗██║  ██║╚███╔███╔╝
   ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝
  ${c.cyan}F A T H E R${c.reset}  ${c.dim}v1.0 — The Bot That Builds Bots${c.reset}
`);
}

// ── Persistence ─────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, "data");
const CONFIG_FILE = path.join(DATA_DIR, "config.json");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function loadConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8")); } catch { return null; }
}
function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2));
}

// ── Readline helpers ────────────────────────────────────────
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function ask(q, def = "") {
  const hint = def ? ` ${c.dim}(${def})${c.reset}` : "";
  return new Promise((r) => rl.question(`  ${c.yellow}?${c.reset} ${q}${hint}: `, (a) => r(a.trim() || def)));
}

async function confirm(q, defYes = true) {
  const a = await ask(`${q} [${defYes ? "Y/n" : "y/N"}]`);
  return a ? a.toLowerCase().startsWith("y") : defYes;
}

async function choose(q, opts) {
  console.log(`\n  ${c.yellow}?${c.reset} ${q}`);
  opts.forEach((o, i) => console.log(`    ${c.cyan}${i + 1})${c.reset} ${o}`));
  while (true) {
    const a = await ask(`Chọn (1-${opts.length})`);
    const n = parseInt(a);
    if (n >= 1 && n <= opts.length) return n - 1;
    log.warn("Số không hợp lệ.");
  }
}

// ── Spinner ─────────────────────────────────────────────────
function spinner(text) {
  const f = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
  let i = 0;
  const id = setInterval(() => {
    process.stdout.write(`\r  ${c.cyan}${f[i++ % f.length]}${c.reset} ${text}`);
  }, 80);
  return {
    stop: (msg) => {
      clearInterval(id);
      process.stdout.write(`\r${" ".repeat(text.length + 10)}\r`);
      if (msg) console.log(`  ${msg}`);
    },
  };
}

// ── OpenAI client ───────────────────────────────────────────
function makeClient(cfg) {
  return new OpenAI({
    baseURL: cfg.baseURL,
    apiKey: cfg.apiKey || "not-needed",
    timeout: 120000,
  });
}

async function chat(client, model, messages, opts = {}) {
  const res = await client.chat.completions.create({
    model,
    messages,
    max_tokens: opts.max_tokens || 4096,
    temperature: opts.temperature ?? 0.7,
  });
  return res.choices?.[0]?.message?.content || "";
}

// ============================================================
//  STEP 1: Telegram Bot Token
// ============================================================
async function setupTelegram(existing) {
  log.step(1, 4, "Telegram Bot Token");
  console.log();
  log.dim("Cách tạo:");
  log.dim("  1. Mở Telegram → tìm @BotFather");
  log.dim("  2. Gửi /newbot → đặt tên → copy token");
  log.dim("  3. Token dạng: 123456789:ABCdefGhIJKlmNoPQRs");
  console.log();

  if (existing) {
    const masked = existing.slice(0, 8) + "••••" + existing.slice(-4);
    log.info(`Token hiện tại: ${masked}`);
    if (await confirm("Giữ token cũ?")) return existing;
  }

  const https = require("https");
  while (true) {
    const token = await ask("Telegram Bot Token");
    if (!token || !token.includes(":")) { log.warn("Token phải chứa ':'"); continue; }

    const s = spinner("Kiểm tra token...");
    try {
      const info = await new Promise((resolve, reject) => {
        https.get(`https://api.telegram.org/bot${token}/getMe`, (res) => {
          let d = "";
          res.on("data", (ch) => (d += ch));
          res.on("end", () => {
            try { const j = JSON.parse(d); resolve(j.ok ? j.result : null); }
            catch { resolve(null); }
          });
        }).on("error", reject);
      });
      s.stop();
      if (info) { log.ok(`Bot: @${info.username} (${info.first_name})`); return token; }
      else log.err("Token không hợp lệ.");
    } catch (e) {
      s.stop();
      log.err(`Lỗi mạng: ${e.message}`);
      if (await confirm("Vẫn dùng token này?", false)) return token;
    }
  }
}

// ============================================================
//  STEP 2: OpenAI-compatible LLM
// ============================================================
async function setupLLM(existing) {
  log.step(2, 4, "OpenAI-Compatible LLM");
  console.log();
  log.dim("Hỗ trợ mọi server có /v1/chat/completions:");
  log.dim("  LM Studio, Ollama, vLLM, LocalAI, OpenRouter, llama.cpp...");
  console.log();

  if (existing?.baseURL) {
    log.info(`Hiện tại: ${existing.baseURL} | model: ${existing.model}`);
    if (await confirm("Giữ config cũ?")) return existing;
  }

  // ── Base URL ──
  const presetIdx = await choose("Server LLM của bạn:", [
    "LM Studio        → http://localhost:1234/v1",
    "Ollama           → http://localhost:11434/v1",
    "LocalAI          → http://localhost:8080/v1",
    "llama.cpp        → http://localhost:8080/v1",
    "text-gen-webui   → http://localhost:5000/v1",
    "OpenRouter       → https://openrouter.ai/api/v1",
    "Tự nhập URL khác",
  ]);

  const presetURLs = [
    "http://localhost:1234/v1",
    "http://localhost:11434/v1",
    "http://localhost:8080/v1",
    "http://localhost:8080/v1",
    "http://localhost:5000/v1",
    "https://openrouter.ai/api/v1",
    "",
  ];

  let baseURL = presetURLs[presetIdx];
  if (!baseURL) {
    baseURL = await ask("Base URL (có /v1)", "http://localhost:1234/v1");
  } else {
    baseURL = await ask("Base URL", baseURL);
  }
  if (!baseURL.startsWith("http")) baseURL = "http://" + baseURL;
  if (!baseURL.includes("/v1")) baseURL = baseURL.replace(/\/$/, "") + "/v1";

  // ── API Key ──
  const isLocal = baseURL.includes("localhost") || baseURL.includes("127.0.0.1");
  let apiKey;
  if (isLocal) {
    log.dim("→ Local server, bỏ qua API key.");
    apiKey = "not-needed";
  } else {
    apiKey = await ask("API Key") || "not-needed";
  }

  // ── List models ──
  const client = makeClient({ baseURL, apiKey });

  const s = spinner("Lấy danh sách model...");
  let models = [];
  try {
    const list = await client.models.list();
    for await (const m of list) models.push(m.id);
    models = models.slice(0, 20);
  } catch {}
  s.stop();

  let model;
  if (models.length > 0) {
    log.ok(`Tìm thấy ${models.length} model:`);
    models.forEach((m, i) => console.log(`    ${c.cyan}${i + 1})${c.reset} ${m}`));
    console.log();
    const a = await ask(`Chọn (1-${models.length}) hoặc gõ tên`);
    const n = parseInt(a);
    model = (n >= 1 && n <= models.length) ? models[n - 1] : a;
  } else {
    log.warn("Không lấy được danh sách model.");
    model = await ask("Nhập tên model");
  }

  // ── Test ──
  console.log();
  const s2 = spinner("Test kết nối...");
  try {
    const reply = await chat(client, model, [
      { role: "user", content: "Reply with exactly one word: OK" },
    ], { max_tokens: 20, temperature: 0 });
    s2.stop();
    log.ok(`Thành công! Reply: "${reply.trim().slice(0, 60)}"`);
  } catch (e) {
    s2.stop();
    log.err(`Lỗi: ${e.message}`);
    log.warn("Kiểm tra: server đang chạy? URL đúng? model đúng?");
    if (!await confirm("Vẫn tiếp tục?", false)) return setupLLM();
  }

  return { baseURL, apiKey, model };
}

// ============================================================
//  STEP 3: Bot Design (AI tự build)
// ============================================================
const ARCHITECT_PROMPT = `You are ClawFather 🦞, an expert Telegram bot architect.

The user will describe a bot they want. You MUST respond with ONLY a valid JSON object (no markdown fences, no explanation before or after):

{
  "name": "short bot name (2-4 words)",
  "description": "1-line description",
  "system_prompt": "Complete system prompt for this bot. 200+ words. Include: personality, rules, capabilities, response format, edge cases, language. Production-ready.",
  "welcome_message": "The /start greeting",
  "sample_qa": [
    {"q": "example user question", "a": "expected answer"},
    {"q": "another question", "a": "another answer"},
    {"q": "edge case question", "a": "how bot handles it"}
  ],
  "features": ["capability 1", "capability 2", "capability 3"],
  "pipeline": {
    "temperature": 0.7,
    "max_tokens": 1024,
    "context_window": 20
  }
}

RULES:
- system_prompt: 200+ words, professional, comprehensive, production-ready
- Write in the SAME LANGUAGE the user uses
- Include edge cases, refusal conditions, personality
- Pipeline should match bot purpose (low temp for factual, high for creative)
- Output ONLY the JSON, nothing else`;

async function designBot(llm) {
  log.step(3, 4, "Thiết kế Bot");
  console.log();
  log.dim("Mô tả bot bạn muốn tạo. Càng chi tiết càng tốt!");
  log.dim("Ví dụ:");
  log.dim('  "Bot tư vấn sức khỏe, nhẹ nhàng, luôn khuyên đi khám bác sĩ"');
  log.dim('  "Bot dạy tiếng Anh cho người Việt, sửa lỗi ngữ pháp"');
  log.dim('  "Bot hỗ trợ kỹ thuật cho sản phẩm X"');
  log.dim('  "Bot viết content marketing, style Gen Z"');
  console.log();

  const client = makeClient(llm);

  while (true) {
    const description = await ask("Mô tả bot của bạn");
    if (!description) { log.warn("Hãy mô tả bot."); continue; }

    const s = spinner("🧠 AI đang thiết kế bot...");
    try {
      const raw = await chat(client, llm.model, [
        { role: "system", content: ARCHITECT_PROMPT },
        { role: "user", content: `Tôi muốn tạo bot: ${description}` },
      ], { max_tokens: 4096, temperature: 0.7 });
      s.stop();

      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error("AI không trả về JSON hợp lệ");
      let botData = JSON.parse(jsonMatch[0]);

      // ── Preview & refine loop ──
      while (true) {
        console.log();
        console.log(`  ${c.bold}${"═".repeat(56)}${c.reset}`);
        console.log(`  ${c.bold}${c.green}🤖 ${botData.name}${c.reset}`);
        console.log(`  ${c.dim}${botData.description}${c.reset}`);
        console.log(`  ${"─".repeat(56)}`);

        console.log(`  ${c.bold}Features:${c.reset}`);
        (botData.features || []).forEach((f) => console.log(`    • ${f}`));

        console.log(`\n  ${c.bold}Welcome:${c.reset} ${botData.welcome_message || "(none)"}`);
        console.log(`  ${c.bold}Pipeline:${c.reset} temp=${botData.pipeline?.temperature ?? 0.7}, tokens=${botData.pipeline?.max_tokens ?? 1024}, context=${botData.pipeline?.context_window ?? 20}`);

        if (botData.sample_qa?.length) {
          console.log(`\n  ${c.bold}Sample Q&A:${c.reset}`);
          botData.sample_qa.slice(0, 3).forEach((qa) => {
            console.log(`    ${c.cyan}👤${c.reset} ${qa.q}`);
            console.log(`    ${c.green}🤖${c.reset} ${qa.a}`);
          });
        }

        console.log(`\n  ${c.bold}System Prompt (preview):${c.reset}`);
        console.log(`  ${c.dim}${botData.system_prompt?.slice(0, 400)}...${c.reset}`);
        console.log(`  ${"═".repeat(56)}`);

        const action = await choose("Tiếp theo:", [
          "✅ Lưu — Hoàn hảo!",
          "✏️  Chỉnh sửa — Yêu cầu AI sửa",
          "📋 Xem đầy đủ System Prompt",
          "🔄 Làm lại từ đầu",
          "❌ Hủy",
        ]);

        if (action === 0) return botData;

        if (action === 1) {
          console.log();
          log.dim('Ví dụ: "thêm rule không nói chính trị", "tone vui hơn", "giảm temp 0.3"');
          const fix = await ask("Bạn muốn sửa gì?");
          if (!fix) continue;

          const s2 = spinner("🔧 Đang sửa...");
          try {
            const raw2 = await chat(client, llm.model, [
              { role: "system", content: ARCHITECT_PROMPT },
              { role: "user", content: `Bot hiện tại:\n${JSON.stringify(botData, null, 2)}\n\nChỉnh sửa: ${fix}\n\nTrả về JSON đầy đủ đã sửa.` },
            ], { max_tokens: 4096 });
            s2.stop();

            const m = raw2.match(/\{[\s\S]*\}/);
            if (m) { botData = JSON.parse(m[0]); log.ok("Đã cập nhật!"); }
            else log.err("Lỗi parse, giữ bản cũ.");
          } catch (e) {
            s2.stop();
            log.err(e.message);
          }
          continue;
        }

        if (action === 2) {
          console.log(`\n  ${c.bold}── Full System Prompt ──${c.reset}\n`);
          console.log(botData.system_prompt);
          console.log(`\n  ${"─".repeat(56)}\n`);
          continue;
        }

        if (action === 3) break; // restart outer loop
        if (action === 4) return null;
      }
      continue; // new description

    } catch (e) {
      if (typeof s !== "undefined" && s.stop) s.stop();
      log.err(`Lỗi: ${e.message}`);
      if (!await confirm("Thử lại?")) return null;
    }
  }
}

// ============================================================
//  STEP 4: Review & Save
// ============================================================
async function reviewAndSave(cfg) {
  log.step(4, 4, "Review & Lưu");
  console.log();
  const masked = cfg.telegram.token.slice(0, 8) + "••••" + cfg.telegram.token.slice(-4);
  console.log(`  ${c.bold}${"═".repeat(56)}${c.reset}`);
  console.log(`  ${c.cyan}Telegram:${c.reset}  ${masked}`);
  console.log(`  ${c.cyan}LLM:${c.reset}       ${cfg.llm.baseURL}`);
  console.log(`  ${c.cyan}Model:${c.reset}     ${cfg.llm.model}`);
  console.log(`  ${c.cyan}Bot:${c.reset}       ${cfg.bot.name} — ${cfg.bot.description}`);
  console.log(`  ${c.cyan}Pipeline:${c.reset}  temp=${cfg.bot.pipeline?.temperature}, tokens=${cfg.bot.pipeline?.max_tokens}`);
  console.log(`  ${"═".repeat(56)}`);

  saveConfig(cfg);
  log.ok(`Config lưu tại: ${CONFIG_FILE}`);
}

// ============================================================
//  Bot Runner
// ============================================================
async function runBot(cfg) {
  const TelegramBot = require("node-telegram-bot-api");
  const bot = new TelegramBot(cfg.telegram.token, { polling: true });
  const client = makeClient(cfg.llm);
  const histories = new Map();
  const ctxWin = cfg.bot.pipeline?.context_window || 20;

  console.log();
  console.log(`  ${c.bold}${c.green}${"═".repeat(56)}${c.reset}`);
  console.log(`  ${c.bold}${c.green}  🦞 "${cfg.bot.name}" đang chạy!${c.reset}`);
  console.log(`  ${c.green}  Mở Telegram → nhắn bot để test${c.reset}`);
  console.log(`  ${c.green}  Ctrl+C để dừng${c.reset}`);
  console.log(`  ${c.bold}${c.green}${"═".repeat(56)}${c.reset}`);
  console.log();

  bot.onText(/\/start/, (msg) => {
    bot.sendMessage(msg.chat.id, cfg.bot.welcome_message || "Xin chào!");
    log.bot(`/start từ ${msg.from.first_name} (${msg.from.id})`);
  });

  bot.onText(/\/clear/, (msg) => {
    histories.delete(msg.chat.id);
    bot.sendMessage(msg.chat.id, "🗑 Đã xóa lịch sử.");
  });

  bot.onText(/\/info/, (msg) => {
    bot.sendMessage(msg.chat.id,
      `🤖 *${cfg.bot.name}*\n${cfg.bot.description}\n\n🌡 temp: ${cfg.bot.pipeline?.temperature}\n📝 tokens: ${cfg.bot.pipeline?.max_tokens}\n💬 context: ${ctxWin}`,
      { parse_mode: "Markdown" },
    );
  });

  bot.on("message", async (msg) => {
    if (!msg.text || msg.text.startsWith("/")) return;
    const chatId = msg.chat.id;

    log.bot(`[${msg.from.first_name}] ${msg.text.slice(0, 80)}`);
    bot.sendChatAction(chatId, "typing");

    if (!histories.has(chatId)) histories.set(chatId, []);
    const hist = histories.get(chatId);

    const messages = [
      { role: "system", content: cfg.bot.system_prompt },
      ...hist.slice(-(ctxWin * 2)),
      { role: "user", content: msg.text },
    ];

    try {
      const reply = await chat(client, cfg.llm.model, messages, {
        temperature: cfg.bot.pipeline?.temperature ?? 0.7,
        max_tokens: cfg.bot.pipeline?.max_tokens ?? 1024,
      });

      hist.push({ role: "user", content: msg.text });
      hist.push({ role: "assistant", content: reply });
      if (hist.length > ctxWin * 2) histories.set(chatId, hist.slice(-(ctxWin * 2)));

      if (reply.length > 4000) {
        for (const chunk of reply.match(/[\s\S]{1,4000}/g)) await bot.sendMessage(chatId, chunk);
      } else {
        await bot.sendMessage(chatId, reply);
      }
      log.ok(`Replied (${reply.length} chars)`);
    } catch (e) {
      log.err(e.message);
      bot.sendMessage(chatId, `⚠️ Lỗi: ${e.message.slice(0, 200)}`);
    }
  });

  bot.on("polling_error", (e) => {
    if (e.code !== "ETELEGRAM") log.err(`Polling: ${e.message}`);
  });
}

// ============================================================
//  MAIN
// ============================================================
async function main() {
  banner();

  const existing = loadConfig();

  if (existing?.telegram?.token && existing?.llm?.baseURL && existing?.bot?.system_prompt) {
    log.ok(`Config tìm thấy: "${existing.bot.name}" | ${existing.llm.model}`);

    const action = await choose("Bạn muốn:", [
      "🚀 Chạy bot ngay",
      "🆕 Tạo bot mới (giữ LLM + Telegram config)",
      "⚙️  Setup lại toàn bộ",
      "❌ Thoát",
    ]);

    if (action === 0) { rl.close(); return runBot(existing); }
    if (action === 1) {
      const b = await designBot(existing.llm);
      if (!b) { log.warn("Hủy."); rl.close(); return; }
      existing.bot = b;
      await reviewAndSave(existing);
      if (await confirm("🚀 Chạy bot ngay?")) { rl.close(); return runBot(existing); }
      rl.close(); return;
    }
    if (action === 3) { rl.close(); return; }
  }

  // Full wizard
  const token = await setupTelegram(existing?.telegram?.token);
  const llm = await setupLLM(existing?.llm);
  const b = await designBot(llm);
  if (!b) { log.warn("Không tạo bot."); rl.close(); return; }

  const cfg = { telegram: { token }, llm, bot: b };
  await reviewAndSave(cfg);

  if (await confirm("🚀 Chạy bot ngay?")) { rl.close(); return runBot(cfg); }
  log.ok("Chạy lại: node clawfather.js");
  rl.close();
}

main().catch((e) => { log.err(e.message); process.exit(1); });
